# Algo Trading Platform Starter

Deployed with FastAPI + React + Tailwind.